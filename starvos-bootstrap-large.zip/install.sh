#!/bin/bash
echo "Installing Starvos Panel"

echo "Installing panel dependencies"
cd panel || exit 1
composer install
npm install && npm run build

echo "Building daemon"
cd ../daemon || exit 1
go build -o starvosd ./cmd/daemon

echo "Installation complete"
