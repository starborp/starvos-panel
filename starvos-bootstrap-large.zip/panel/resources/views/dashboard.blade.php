
<!DOCTYPE html>
<html>
<head>
<title>Starvos Dashboard</title>
<script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white">
<div class="flex h-screen">
<aside class="w-64 bg-gray-800 p-4">
<h1 class="text-2xl font-bold text-emerald-400">Starvos</h1>
<nav class="mt-6 space-y-2">
<a class="block text-gray-300 hover:text-white">Dashboard</a>
<a class="block text-gray-300 hover:text-white">Servers</a>
<a class="block text-gray-300 hover:text-white">Files</a>
<a class="block text-gray-300 hover:text-white">Players</a>
<a class="block text-gray-300 hover:text-white">Settings</a>
</nav>
</aside>
<main class="flex-1 p-6 overflow-y-auto">
<h2 class="text-3xl mb-6">Overview</h2>
<div class="grid grid-cols-4 gap-4">
<div class="bg-gray-800 rounded p-4">CPU Usage</div>
<div class="bg-gray-800 rounded p-4">Memory</div>
<div class="bg-gray-800 rounded p-4">Disk</div>
<div class="bg-gray-800 rounded p-4">Network</div>
</div>
</main>
</div>
</body>
</html>
