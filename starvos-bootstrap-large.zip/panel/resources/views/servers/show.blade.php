// resources/views/servers/show.blade.php
