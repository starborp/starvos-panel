// resources/views/servers/index.blade.php
