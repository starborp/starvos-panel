// resources/views/components/card.blade.php
