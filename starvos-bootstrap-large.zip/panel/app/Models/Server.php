// app/Models/Server.php
