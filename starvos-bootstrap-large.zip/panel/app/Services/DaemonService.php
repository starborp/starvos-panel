// app/Services/DaemonService.php
