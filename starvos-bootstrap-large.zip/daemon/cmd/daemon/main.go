// cmd/daemon/main.go
