// internal/runtime/node.go
