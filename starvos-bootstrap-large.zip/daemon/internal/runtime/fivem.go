// internal/runtime/fivem.go
