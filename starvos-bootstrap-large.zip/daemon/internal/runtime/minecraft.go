// internal/runtime/minecraft.go
