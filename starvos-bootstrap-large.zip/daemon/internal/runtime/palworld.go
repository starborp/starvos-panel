// internal/runtime/palworld.go
