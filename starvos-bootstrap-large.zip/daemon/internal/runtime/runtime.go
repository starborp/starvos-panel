// internal/runtime/runtime.go
