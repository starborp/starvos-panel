// internal/api/server.go
