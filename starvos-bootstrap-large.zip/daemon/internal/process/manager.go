// internal/process/manager.go
