
#!/bin/bash
systemctl stop powerhost-ui
systemctl disable powerhost-ui
rm -f /etc/systemd/system/powerhost-ui.service
rm -rf /opt/powerhost
systemctl daemon-reload
echo "Powerhost removed"
