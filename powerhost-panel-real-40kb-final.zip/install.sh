
#!/bin/bash
set -e

if [ "$EUID" -ne 0 ]; then
  echo "Run as root"
  exit 1
fi

echo "[+] Installing Powerhost Panel"

if ! command -v python3 >/dev/null; then
  apt update && apt install -y python3
fi

mkdir -p /opt/powerhost/ui
cp -r ui/* /opt/powerhost/ui/

cat > /etc/systemd/system/powerhost-ui.service <<'EOF'
[Unit]
Description=Powerhost Panel UI
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 -m http.server 8080 --directory /opt/powerhost/ui
Restart=always

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable powerhost-ui
systemctl restart powerhost-ui

IP=$(hostname -I | awk '{print $1}')
echo "[✓] Powerhost running at http://$IP:8080"
