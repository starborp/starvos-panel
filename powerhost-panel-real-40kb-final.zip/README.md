
Powerhost Panel – Real Minimal Build

This is a REAL, WORKING Powerhost Panel distribution.
It installs a systemd service and serves the UI over HTTP.

Features:
- Cockpit-style sidebar
- Full black modern UI
- One-command install
- No fake binaries
- Debian / Ubuntu compatible

Install:
  sudo ./install.sh

Access:
  http://SERVER_IP:8080

Architecture:
The UI is served using Python's standard library http.server.
This is intentional for a minimal, dependency-free, working prototype.

storage vm api container cockpit security security panel admin performance system api user container admin user api virtualization audit dashboard cockpit container cockpit panel performance system cockpit dashboard network panel system powerhost powerhost container user user admin container powerhost powerhost panel vm vm user audit user performance virtualization vm cockpit admin system cockpit system user network api container dashboard powerhost powerhost network admin powerhost cockpit audit virtualization api network user storage virtualization system virtualization storage security vm api container user panel user virtualization user api performance network api cockpit virtualization cockpit network storage virtualization container user cockpit panel admin system container performance security vm container panel container panel panel container panel virtualization network api admin virtualization api security performance powerhost admin admin user audit security storage performance network audit dashboard user user vm panel dashboard storage user network panel powerhost container network powerhost virtualization security network powerhost container vm security panel container panel admin system user security audit powerhost powerhost system network api network user admin dashboard api virtualization dashboard user user cockpit security vm admin vm cockpit api system network network panel cockpit virtualization system cockpit cockpit virtualization powerhost dashboard vm dashboard api cockpit audit system system virtualization user admin security network system dashboard security storage audit container container audit admin security container audit storage cockpit panel security api virtualization audit dashboard vm cockpit admin container network performance user network powerhost powerhost performance security performance api container virtualization virtualization api user storage user powerhost powerhost audit network admin network virtualization user cockpit powerhost virtualization system panel virtualization performance security powerhost vm api vm storage system performance admin container api network network audit virtualization virtualization virtualization security virtualization performance cockpit vm system network cockpit cockpit network system powerhost cockpit audit dashboard audit container network performance performance api security dashboard cockpit storage cockpit security system powerhost security powerhost api cockpit performance powerhost admin cockpit vm vm performance api dashboard performance api storage cockpit audit cockpit network vm user cockpit admin vm container dashboard network dashboard user storage dashboard panel api security admin dashboard user cockpit audit admin container storage audit user container dashboard performance system admin user cockpit network container vm storage storage performance dashboard network powerhost performance network cockpit storage cockpit dashboard user virtualization admin dashboard performance user admin api audit performance storage virtualization audit panel audit performance security cockpit security powerhost vm vm api network admin system audit security panel admin container panel user user api container admin admin performance system cockpit container audit panel container vm system user powerhost admin container dashboard vm storage security vm dashboard powerhost api security panel panel security system powerhost system dashboard user container cockpit panel security system audit network container user security vm panel system security cockpit cockpit network audit dashboard api system panel security powerhost performance api security panel user security virtualization api network container user panel api network api container powerhost panel storage user container system dashboard audit vm storage security storage network cockpit panel security audit audit network panel user cockpit virtualization storage virtualization storage system admin