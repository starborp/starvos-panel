
from flask import Flask, request, session, jsonify, redirect, send_from_directory
import json, os, subprocess, bcrypt, threading, time

BASE = os.path.dirname(__file__)
DATA = os.path.join(BASE, "..", "data")

app = Flask(__name__, static_folder="../ui", static_url_path="")
app.secret_key = os.urandom(24)

def load(p): return json.load(open(os.path.join(DATA,p)))
def save(p,d): json.dump(d, open(os.path.join(DATA,p),"w"), indent=2)

def require():
    if not session.get("user"):
        return False
    return True

@app.route("/")
def index():
    if not require(): return redirect("/login.html")
    return send_from_directory("../ui","index.html")

@app.route("/login", methods=["POST"])
def login():
    u=request.form.get("username")
    p=request.form.get("password","").encode()
    users=load("users.json")
    if u in users and users[u]["enabled"]:
        if bcrypt.checkpw(p, users[u]["password"].encode()):
            session["user"]=u
            return redirect("/")
    return redirect("/login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login.html")

@app.route("/api/stats")
def stats():
    if not require(): return ("",401)
    cpu=open("/proc/loadavg").read().split()[0]
    mem={}
    for l in open("/proc/meminfo"):
        k,v=l.split(":")
        mem[k.strip()]=int(v.strip().split()[0])
    used=mem["MemTotal"]-mem["MemAvailable"]
    disk=subprocess.check_output(["df","-h","/"]).decode().splitlines()[1].split()[4]
    return jsonify({
        "cpu":cpu,
        "ram_used_mb":used//1024,
        "ram_total_mb":mem["MemTotal"]//1024,
        "disk_used":disk
    })

@app.route("/api/security", methods=["GET","POST"])
def security():
    if not require(): return ("",401)
    cfg=load("config.json")
    if request.method=="POST":
        cfg["security_enabled"]=request.json.get("enabled",cfg["security_enabled"])
        cfg["ram_limit_mb"]=int(request.json.get("ram_limit_mb",cfg["ram_limit_mb"]))
        save("config.json",cfg)
    return jsonify(cfg)

@app.route("/api/console")
def console():
    if not require(): return ("",401)
    out=subprocess.check_output(["dmesg","|","tail","-n","50"],shell=True)
    return out.decode(errors="ignore")

def watchdog():
    while True:
        time.sleep(5)
        cfg=load("config.json")
        if not cfg["security_enabled"]: continue
        mem={}
        for l in open("/proc/meminfo"):
            k,v=l.split(":")
            mem[k.strip()]=int(v.strip().split()[0])
        used=(mem["MemTotal"]-mem["MemAvailable"])//1024
        if used>cfg["ram_limit_mb"]:
            subprocess.Popen(["shutdown","-r","now"])

threading.Thread(target=watchdog,daemon=True).start()
app.run(host="0.0.0.0",port=8080)
