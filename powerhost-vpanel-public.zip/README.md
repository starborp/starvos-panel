Powerhost VPanel – Dedicated Server Edition (PUBLIC)

Features:
- Ubuntu / Debian
- Auth login
- Live CPU / RAM / Disk
- Security RAM watchdog (auto reboot)
- Charts
- Console (system logs)
- No license key

Install:
  sudo ./install.sh
