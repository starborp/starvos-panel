
#!/bin/bash
set -e
[ "$EUID" -ne 0 ] && echo "Run as root" && exit 1
apt update && apt install -y python3 python3-pip
pip3 install flask bcrypt >/dev/null
mkdir -p /opt/powerhost-vpanel
cp -r app ui data /opt/powerhost-vpanel/
cat > /etc/systemd/system/powerhost-vpanel.service <<EOF
[Unit]
Description=Powerhost VPanel
After=network.target
[Service]
WorkingDirectory=/opt/powerhost-vpanel
ExecStart=/usr/bin/python3 app/app.py
Restart=always
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable powerhost-vpanel
systemctl restart powerhost-vpanel
echo "Running on http://$(hostname -I | awk '{print $1}'):8080"
