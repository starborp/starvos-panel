Powerhost Panel Phase 1–10 (UI + Structure)
