Phase 1–10 install
