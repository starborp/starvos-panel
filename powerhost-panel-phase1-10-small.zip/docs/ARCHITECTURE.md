Full architecture
