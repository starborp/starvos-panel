#!/bin/bash
echo 'Uninstall placeholder'
