
<?php
return [
  'vanilla' => [
    'type' => 'mojang_manifest',
    'jar' => 'server.jar'
  ],
  'paper' => [
    'type' => 'paper_api',
    'jar' => 'paper.jar'
  ],
  'velocity' => [
    'type' => 'velocity_api',
    'jar' => 'velocity.jar'
  ],
  'spigot' => [
    'type' => 'buildtools',
    'jar' => 'spigot.jar'
  ]
];
