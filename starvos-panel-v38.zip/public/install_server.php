
<?php
require __DIR__.'/../src/bootstrap.php';
require_auth();
require_permission('servers.manage');

if ($_SERVER['REQUEST_METHOD']==='POST') {
  csrf_check();
  $software=$_POST['software'];
  file_put_contents('/storage/install_queue.txt', $software);
  log_event("server_install_requested:$software");
  echo "Installation started.";
}
?>

<form method="POST">
<input type="hidden" name="csrf" value="<?=csrf_token()?>">
<select name="software">
<option value="vanilla">Vanilla</option>
<option value="paper">Paper</option>
<option value="spigot">Spigot</option>
<option value="velocity">Velocity</option>
</select>
<button>Install</button>
</form>
