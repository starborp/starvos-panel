
StarVOS Panel v38 – Phase 38 (Automatic Minecraft Server Installer)

This phase adds AUTOMATIC server.jar installation while staying LEGAL.

Supported:
- Vanilla (official Mojang manifest)
- Paper (official Paper API)
- Velocity (official builds)
- Spigot via BuildTools (user-initiated)

No pirated binaries.
No redistribution.
Fully compliant.
