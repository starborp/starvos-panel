
<?php
$sources = require __DIR__.'/../config/installer_sources.php';
$queue='/storage/install_queue.txt';
$servers='/storage/servers/default';

if (!file_exists($queue)) exit;

$software=trim(file_get_contents($queue));
unlink($queue);

@mkdir($servers,0777,true);

if ($sources[$software]['type']==='paper_api') {
  $json=json_decode(file_get_contents('https://api.papermc.io/v2/projects/paper'),true);
  $version=end($json['versions']);
  $builds=json_decode(file_get_contents("https://api.papermc.io/v2/projects/paper/versions/$version"),true);
  $build=end($builds['builds']);
  $url="https://api.papermc.io/v2/projects/paper/versions/$version/builds/$build/downloads/paper-$version-$build.jar";
  file_put_contents("$servers/paper.jar", file_get_contents($url));
}

if ($sources[$software]['type']==='velocity_api') {
  $json=json_decode(file_get_contents('https://api.papermc.io/v2/projects/velocity'),true);
  $version=end($json['versions']);
  $builds=json_decode(file_get_contents("https://api.papermc.io/v2/projects/velocity/versions/$version"),true);
  $build=end($builds['builds']);
  $url="https://api.papermc.io/v2/projects/velocity/versions/$version/builds/$build/downloads/velocity-$version-$build.jar";
  file_put_contents("$servers/velocity.jar", file_get_contents($url));
}

if ($sources[$software]['type']==='mojang_manifest') {
  $manifest=json_decode(file_get_contents('https://launchermeta.mojang.com/mc/game/version_manifest.json'),true);
  $latest=$manifest['latest']['release'];
  foreach ($manifest['versions'] as $v) {
    if ($v['id']===$latest) {
      $meta=json_decode(file_get_contents($v['url']),true);
      $url=$meta['downloads']['server']['url'];
      file_put_contents("$servers/server.jar", file_get_contents($url));
      break;
    }
  }
}

if ($sources[$software]['type']==='buildtools') {
  file_put_contents("$servers/README.txt","Run BuildTools.jar manually to generate Spigot.");
}
