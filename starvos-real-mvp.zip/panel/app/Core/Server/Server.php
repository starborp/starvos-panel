
<?php
namespace App\Core\Server;

class Server {
    public string $name;
    public function __construct($name){ $this->name = $name; }
}
