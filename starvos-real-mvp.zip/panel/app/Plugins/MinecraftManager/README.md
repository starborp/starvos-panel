
MinecraftManager (MVP)
- Supports selecting server type:
  Paper, Spigot, Purpur, Sponge, BungeeCord, Velocity
- NO external API calls yet
- Only safe local config switching
