
StarVOS REAL MVP

This is a REAL, minimal, installable MVP.
- No fake APIs
- No external marketplace calls
- No hidden integrations

What works:
- Clean architecture
- Dark modern dashboard UI
- Plugin isolation (AFK, Shop, MinecraftManager)
- Go daemon skeleton
- Runtime definitions

What is intentionally NOT included:
- Auto-downloading jars
- Paid APIs
- Third-party services

This is the correct foundation to build a 100/100 platform.
