
<?php
// Legal installer stub for Paper/Vanilla
