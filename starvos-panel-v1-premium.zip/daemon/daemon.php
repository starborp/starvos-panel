
<?php
require 'runner.php';
require 'installer.php';
while(true){ sleep(1); }
