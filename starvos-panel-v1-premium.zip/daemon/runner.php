
<?php
function start_server($cmd,$dir){
 $descriptorspec=[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']];
 proc_open($cmd,$descriptorspec,$pipes,$dir);
}
