
StarVOS Panel v1 Premium

Features:
- Secure PHP panel (auth, CSRF, sessions)
- Premium dark UI (black/red)
- Real JS/CSS assets
- Daemon with Minecraft execution wiring
- Vanilla / Paper / Spigot / Velocity
- Docker deployment
