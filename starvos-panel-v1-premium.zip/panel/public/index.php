
<?php session_start(); require __DIR__.'/../src/db.php'; ?>
<link rel="stylesheet" href="/assets/css/app.css">
<script src="/assets/js/app.js"></script>
<div class="app">
 <aside class="sidebar">StarVOS</aside>
 <main class="content">Dashboard</main>
</div>
