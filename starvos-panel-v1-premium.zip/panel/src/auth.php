
<?php
function login($email,$pass){
 $stmt=db()->prepare("SELECT * FROM users WHERE email=?");
 $stmt->execute([$email]);
 $u=$stmt->fetch(PDO::FETCH_ASSOC);
 if($u && password_verify($pass,$u['password'])){
   session_regenerate_id(true);
   $_SESSION['uid']=$u['id'];
   return true;
 }
 return false;
}
