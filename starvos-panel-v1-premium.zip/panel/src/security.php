
<?php
function csrf_token(){
 if(!isset($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32));
 return $_SESSION['csrf'];
}
function csrf_check(){
 if($_POST['csrf']!==($_SESSION['csrf']??'')) die('CSRF');
}
