
<?php
function db(){
 static $db;
 if(!$db){
  $db=new PDO('sqlite:/storage/database.sqlite');
  $db->exec("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,email TEXT,password TEXT)");
 }
 return $db;
}
