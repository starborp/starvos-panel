
<?php return [
 'paper'=>['cmd'=>'java -Xmx2G -jar paper.jar nogui'],
 'vanilla'=>['cmd'=>'java -Xmx2G -jar server.jar nogui'],
 'spigot'=>['cmd'=>'java -Xmx2G -jar spigot.jar nogui'],
 'velocity'=>['cmd'=>'java -Xmx2G -jar velocity.jar'],
];
